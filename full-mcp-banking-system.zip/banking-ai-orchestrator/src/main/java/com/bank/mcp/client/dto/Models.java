package com.bank.mcp.client.dto;
import com.fasterxml.jackson.annotation.JsonPropertyDescription;

public enum BankingIntent { MAKE_PAYMENT, VIEW_BALANCE, UNKNOWN }
public sealed interface BankingPayload permits PaymentPayload, BalancePayload {}
public record PaymentPayload(
    @JsonPropertyDescription("Source bank account alias") String sourceAccountAlias,
    @JsonPropertyDescription("Recipient individual name") String beneficiaryAlias,
    @JsonPropertyDescription("Total transactional volume value") Double amount,
    @JsonPropertyDescription("The 3-letter currency code, e.g. USD") String currency
) implements BankingPayload {}
public record BalancePayload(
    @JsonPropertyDescription("Target funding account alias string") String accountAlias
) implements BankingPayload {}