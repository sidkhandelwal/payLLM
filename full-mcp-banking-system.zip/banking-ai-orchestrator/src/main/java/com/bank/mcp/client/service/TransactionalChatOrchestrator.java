package com.bank.mcp.client.service;
import com.bank.mcp.client.dto.BankingIntent;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.client.ChatClient;
import org.springframework.ai.chat.client.advisor.MessageChatMemoryAdvisor;
import org.springframework.ai.chat.memory.InMemoryChatMemory;
import org.springframework.ai.mcp.client.McpClient;
import org.springframework.stereotype.Service;
import java.util.regex.Pattern;

@Service
public class TransactionalChatOrchestrator {
    private static final Logger log = LoggerFactory.getLogger(TransactionalChatOrchestrator.class);
    private final ChatClient chatClient;
    private static final Pattern INJECTION_GUARDRAIL = Pattern.compile("(?i)(drop\\s+table|bypass\\s+entitlement|override\\s+auth)");

    public TransactionalChatOrchestrator(ChatClient.Builder chatClientBuilder, McpClient mcpClient) {
        this.chatClient = chatClientBuilder
            .defaultSystem("""
                You are a secure corporate banking conversational agent.
                You have visibility into accounts, beneficiaries, payments, and histories via distinct tools.
                Always delegate object lookups and transactional operations directly to your tools.
                Never communicate raw underlying database string keys or account numbers back to the user channel.
                """)
            .defaultAdvisors(new MessageChatMemoryAdvisor(new InMemoryChatMemory()))
            .defaultTools(mcpClient.getTools().toArray()) 
            .build();
    }

    public String processChatIntent(String rawUserPrompt, String userContextJwt) {
        if (INJECTION_GUARDRAIL.matcher(rawUserPrompt).find()) {
            return "Transaction Terminated: Safety Policy Violation Detected.";
        }
        try {
            BankingIntent detectedIntent = this.chatClient.prompt()
                .user("Identify the main intent category of this prompt: " + rawUserPrompt)
                .call()
                .entity(BankingIntent.class);

            if (detectedIntent == BankingIntent.UNKNOWN || detectedIntent == null) {
                return "I'm sorry, I can only assist with verified banking transactions like payments or balances.";
            }

            return this.chatClient.prompt()
                .user(rawUserPrompt)
                .system(sys -> sys.param("user_token", userContextJwt))
                .call()
                .content();
        } catch (Exception ex) {
            return "Transaction Execution Failure: " + ex.getMessage();
        }
    }
}