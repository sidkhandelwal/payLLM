package com.bank.mcp.client.config;
import org.springframework.ai.mcp.client.McpClient;
import org.springframework.ai.mcp.client.McpSyncClient;
import org.springframework.ai.mcp.client.transport.HttpClientTransport;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.client.RestClient;

@Configuration
public class McpClientConfig {
    @Value("${spring.ai.mcp.client.streamable-http.connections.governance-hub.url}")
    private String mcpServerUrl;

    @Bean
    public McpClient mcpClient(RestClient.Builder restClientBuilder) {
        HttpClientTransport transport = new HttpClientTransport(mcpServerUrl, restClientBuilder);
        McpSyncClient syncClient = new McpSyncClient(transport);
        syncClient.initialize();
        return syncClient;
    }
}