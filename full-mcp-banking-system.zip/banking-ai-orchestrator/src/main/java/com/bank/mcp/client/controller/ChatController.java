package com.bank.mcp.client.controller;
import com.bank.mcp.client.service.TransactionalChatOrchestrator;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/banking")
@CrossOrigin(origins = "*")
public class ChatController {
    private final TransactionalChatOrchestrator orchestrator;

    public ChatController(TransactionalChatOrchestrator orchestrator) { this.orchestrator = orchestrator; }

    public record ChatRequest(String message) {}
    public record ChatResponse(String status, String reply) {}

    @PostMapping("/chat")
    public ResponseEntity<ChatResponse> handleBankingChat(
            @RequestBody ChatRequest request,
            @RequestHeader(value = "Authorization", defaultValue = "Bearer MOCK_JWT") String authHeader) {
        String jwtToken = authHeader.replace("Bearer ", "").trim();
        String aiReply = orchestrator.processChatIntent(request.message(), jwtToken);
        return ResponseEntity.ok(new ChatResponse("SUCCESS", aiReply));
    }
}